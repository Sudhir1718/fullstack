package com.yoga.shanthikrishna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShanthikrishnaApplicationTests {

	@Test
	void contextLoads() {
	}

}
